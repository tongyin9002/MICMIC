## ---- fig.show='hold'----------------------------------------------------
library(MICMIC)
data("TCGA_HNSC_data")
data("TCGA_STAD_data")

## ---- fig.show='hold', eval = FALSE--------------------------------------
#  gene_name="MLH1"
#  network<-CMI_met_cis_network(met_data_matrix=STAD_met_data_matrix,
#                               exp_data_matrix=STAD_exp_data_matrix,
#                               gene_list=gene_name,distance=300000,ref_gene_bed=STAD_ref_gene_bed,
#                               ref_CpGs_bed=STAD_ref_CpGs_bed,outfiledir=getwd(),
#                               pvalue_cut=0.0001,core_num=1)
#  network[1:10,1:10]

## ---- fig.show='hold', eval = TRUE---------------------------------------
gene_name="MLH1"
result<-generate_regulator_info(met_data_matrix=STAD_met_data_matrix,
                                exp_data_matrix=STAD_exp_data_matrix,
                                gene_list=gene_name,outfiledir=getwd(),
                                ref_gene_bed=STAD_ref_gene_bed,ref_CpGs_bed=STAD_ref_CpGs_bed
                                )
head(result)

## ---- fig.show=FALSE, eval = FALSE, results = "hide"---------------------
#  gene_name="MLH1"
#  MICMIC_plotting(gene_name=gene_name,met_data_matrix=STAD_met_data_matrix,
#                  exp_data_matrix=STAD_exp_data_matrix,
#                  control_id=STAD_control_id,distance=400000,ref_gene_bed=STAD_ref_gene_bed,
#                  ref_CpGs_bed=STAD_ref_CpGs_bed,sample_class=STAD_sample_class,
#                  outfiledir=getwd())
#  

## ---- fig.show='hold'----------------------------------------------------
library(MICMIC)
x<-rnorm(1000)
y<-rnorm(1000)
MI_result<-MI(x,y)
MI_result

## ---- fig.show='hold'----------------------------------------------------
y<-x*x+0.5*x+rnorm(1000,sd=0.1)
MI(x,y)

## ---- fig.show='hold'----------------------------------------------------
MI(x,y,pvalue=TRUE)

## ---- fig.show='hold'----------------------------------------------------
MI(x,y,unit="nats")

## ---- fig.show='hold', eval = FALSE--------------------------------------
#  entropy(x,method="density")
#  MI(x,y,method="KDE")
#  

## ---- fig.show='hold'----------------------------------------------------
x<-rnorm(1000)
y<-0.5*x+rnorm(1000,sd=0.1)
z<-0.8*y+rnorm(1000,sd=0.1)
MI(x,y)
MI(y,z)
MI(x,z)

CMIxy<-CMI(x,y,z,pvalue=TRUE)
CMIxy$CMI
CMIxy$adj.pvalue
CMIxz<-CMI(x,z,y,pvalue=TRUE)
CMIxz$CMI
CMIxz$adj.pvalue

## ---- fig.show='hold'----------------------------------------------------
x=rnorm(100,mean=20,sd=6)
y=x+rnorm(100,mean=0,sd=3)
w=y*0.1+rnorm(100,mean=18,sd=1)
v=y*0.15+rnorm(100,mean=17,sd=1)
z=2*w+v+rnorm(100,mean=0,sd=0.1)
a=rnorm(100,mean=20,sd=5)
b=0.9*a+rnorm(100,mean=2,sd=1)
c=b-rnorm(100,mean=0,sd=3)
mydata<-rbind(x,y,w,v,z,a,b,c)
MI_PC_net<-PC_para(mydata,max_L=0,pre_adj=NULL,log_file_dir=getwd(),
                   edgemode="pvalue",pvalue_cut=0.001,core_num=1)
MI_PC_net

## ---- fig.show='hold'----------------------------------------------------
CMI_PC_net<-PC_para(mydata,max_L=1,method="CMII",pre_adj=NULL,log_file_dir=getwd(),
                    edgemode="pvalue",pvalue_cut=0.001,core_num=1)
CMI_PC_net

