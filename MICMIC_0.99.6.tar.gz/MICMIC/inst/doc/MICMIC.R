## ---- fig.show='hold', eval = FALSE--------------------------------------
#  install.packages("MICMIC_0.99.6.tar.gz",repos=NULL)

## ---- fig.show='hold'----------------------------------------------------
library(MICMIC)
x<-rnorm(1000)
y<-rnorm(1000)
MI_result<-MI(x,y)
MI_result

## ---- fig.show='hold'----------------------------------------------------
y<-x*x+x+rnorm(1000)
MI(x,y)

## ---- fig.show='hold'----------------------------------------------------
MI(x,y,pvalue=TRUE)

## ---- fig.show='hold'----------------------------------------------------
MI(x,y,unit="nats")

## ---- fig.show='hold'----------------------------------------------------
x<-rnorm(1000)
y<-0.5*x+rnorm(1000,sd=0.1)
z<-0.8*y+rnorm(1000,sd=0.1)
MI(x,y)
MI(y,z)
MI(x,z)
CMIxy<-CMI(x,y,z,pvalue=TRUE)
CMIxy$CMI
CMIxy$adj.pvalue
CMIxz<-CMI(x,z,y,pvalue=TRUE)
####the lower value of CMI between x and z on the
####condition of y, indicates that a indirect 
####connection between x and z which is depending on y 
CMIxz$CMI                    
CMIxz$adj.pvalue

## ---- fig.show='hold'----------------------------------------------------
x=rnorm(100,mean=20,sd=6)
y=x+rnorm(100,mean=0,sd=3)
w=y*0.1+rnorm(100,mean=18,sd=1)
v=y*0.15+rnorm(100,mean=17,sd=1)
z=2*w+v+rnorm(100,mean=0,sd=0.1)
a=rnorm(100,mean=20,sd=5)
b=0.9*a+rnorm(100,mean=2,sd=1)
c=b-rnorm(100,mean=0,sd=3)
mydata<-rbind(x,y,w,v,z,a,b,c)
MI_PC_net<-PC_para(mydata,max_L=0,pre_adj=NULL,log_file_dir=tempdir(),
                   edgemode="pvalue",pvalue_cut=0.001,core_num=1)

## ---- fig.show='hold'----------------------------------------------------
CMI_PC_net<-PC_para(mydata,max_L=1,method="CMII",pre_adj=NULL,
                    log_file_dir=tempdir(),
                    edgemode="pvalue",pvalue_cut=0.001,core_num=1)

## ---- fig.show='hold', eval = FALSE--------------------------------------
#  library(MICMIC)
#  data("LIHC")
#  head(sample_data)
#  head(exp_data_matrix)
#  head(met_data_matrix)

## ---- fig.show='hold', eval = FALSE--------------------------------------
#  
#  library(MICMIC)
#  
#  data(LIHC)
#  head(gene_list)
#  
#  outfiledir<-paste0(example_dir,"/result")    ######output directory for each gene
#  summarydir<-paste0(example_dir,"/result/summary")##output directory for summary result
#  dir.create(outfiledir)
#  dir.create(summarydir)
#  
#  setwd(outfiledir)
#  
#  ####infer the cis-acting methylation regulatory network
#  mynet<-CMI_met_cis_network(met_data_matrix,exp_data_matrix,gene_list,
#                             distance=300000,ref_gene_bed,ref_CpGs_bed,
#                             outfiledir=outfiledir,pvalue_cut=0.01,core_num=1) ###
#  #core num can be set above 1 when using linux system
#  

## ---- fig.show='hold', eval = FALSE--------------------------------------
#  ####generate result table####
#  generate_regulator_info(met_data_matrix,exp_data_matrix,
#                          gene_list,outfiledir,ref_gene_bed,ref_CpGs_bed)

## ---- fig.show='hold', eval = FALSE--------------------------------------
#  ####merge result tables for genes####
#  merge_regulator_info(gene_list,outfiledir,statisticfiledir=summarydir,
#                       ref_gene_bed)
#  
#  ####read the direct regulation information####
#  direct_info<-read.table(paste0(summarydir,"/direct_information.txt"),
#                          sep="\t",as.is=TRUE)
#  
#  ####identify the direct regulation sites of HDAC11
#  direct_info[which(direct_info[,"target_name"]=="HDAC11"),]

## ---- fig.show=FALSE, eval = FALSE, results = "hide"---------------------
#  ####plot the cis-acting regulatory network####
#  control_id=sample_data[which(sample_data[,"stage"]=="control"),"sample_id"]
#  MICMIC_plotting(gene_name="HDAC11",met_data_matrix,exp_data_matrix,
#                  control_id=control_id,distance=300000,ref_gene_bed,
#                  ref_CpGs_bed,sample_data[,c("sample_id","stage")],
#                  outfiledir=outfiledir)

## ---- fig.show=FALSE, eval = FALSE---------------------------------------
#  ################Plot the histone mark signal around DREs
#  data(histone_mark)      ##load the histone mark score surrounding the CpGs used in this example
#  head(CpGs_score_H3K4me1)
#  head(CpGs_score_p300)
#  
#  direct_info<-read.table(paste0(summarydir,"/direct_information.txt"),
#                          sep="\t",as.is=TRUE)
#  direct_info$type<-"positive"
#  direct_info$type[which(direct_info[,"pearson_cor"]<0)]<-"negative"
#  
#  mycolors<-c("control"="grey","positive"="blue","negative"="red")
#  name="H3K4me1"
#  CpGs_score<-CpGs_score_H3K4me1
#  plot_histone_mark_score(direct_info,name,CpGs_score,
#                          colors=mycolors,
#                          range=3000,figure_dir=summarydir,CpGs_annotation)
#  
#  mycolors<-c("control"="grey","positive"="blue","negative"="red")
#  name="p300"
#  CpGs_score<-CpGs_score_p300
#  range<-3000
#  plot_histone_mark_score(direct_info,name,CpGs_score,
#                          colors=mycolors,
#                          range=3000,figure_dir=summarydir,CpGs_annotation)
#  

## ---- fig.show=FALSE, eval = FALSE---------------------------------------
#  
#  data(TF_data)
#  motif_data[1,]
#  
#  CpGs_list=unique(CpG_target[,1])
#  
#  ##########Calculate the TF enrichment on the regulatory sites
#  TF_binding<-TF_binding_enrichment(motif_data=motif_data,CpGs_list=CpGs_list,control_list=control_list)
#  
#  head(TF_binding[,1:6])
#  
#  ##########Generate TF-target regulation network
#  TF_network<-TF_target_network(TF_binding,CpG_target)
#  
#  head(TF_network)

## ---- fig.show=FALSE, eval = FALSE---------------------------------------
#  TF_circuit<-selfconnected_TF_circuit(TF_binding,CpG_target,CpGs_in_SE)
#  TF_circuit_core<-select_TF_circuit(TF_circuit,OR=1.05,super_enhancer=TRUE)
#  head(TF_circuit_core)

## ---- fig.show=FALSE, eval = FALSE---------------------------------------
#  data(TF_data)
#  head(function_gmt)
#  
#  core_TFs<-unique(TF_circuit_core[,"motif_TF"])
#  ######User can assign cluster number to the CRC TFs by any clustering method
#  cluster<-sample(c(1,2),length(core_TFs),replace=TRUE)
#  core_TF_clusters<-data.frame(core_TFs,cluster)
#  
#  ######Study the function of targets of the CRC TF in each cluster
#  circuit_function<-functional_enrichment_of_core_circuit(TF_network,
#                                                          core_TF_clusters,
#                                                          function_gmt)
#  head(circuit_function)

## ---- fig.show=FALSE, eval = FALSE---------------------------------------
#  ######Visualization of the interconnected CRC network
#  outpath=paste0(example_dir,"/result/summary")
#  plot_core_circuit(TF_circuit_core,TF_class_data=core_TF_clusters,
#                    TF_pathway_data=circuit_function,outpath=outpath)

